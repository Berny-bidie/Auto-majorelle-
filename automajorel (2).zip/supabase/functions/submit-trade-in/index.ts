import "jsr:@supabase/functions-js/edge-runtime.d.ts";
import { createClient } from "https://esm.sh/@supabase/supabase-js@2.57.4";

const maxBodyBytes = 38 * 1024 * 1024;
const maxPhotoBytes = 5 * 1024 * 1024;
const allowedOriginSuffixes = [".manus.computer", ".manuspre.computer"];
const uuidPattern = /^[0-9a-f]{8}-[0-9a-f]{4}-[1-8][0-9a-f]{3}-[89ab][0-9a-f]{3}-[0-9a-f]{12}$/i;

type TradeInBody = {
  submissionId: string;
  name: string;
  phone: string;
  email?: string;
  message?: string;
  consent: boolean;
  website?: string;
  brand: string;
  model: string;
  year: number;
  mileageKm: number;
  fuel: string;
  condition: string;
  photos: string[];
};

type ValidPhoto = { bytes: Uint8Array; contentType: string; extension: string };

function allowedOrigin(origin: string | null): origin is string {
  if (!origin) return false;
  let url: URL;
  try {
    url = new URL(origin);
  } catch {
    return false;
  }
  if (url.protocol !== "https:" && url.hostname !== "localhost" && url.hostname !== "127.0.0.1") return false;
  const configured = Deno.env.get("ALLOWED_ORIGINS")?.split(",").map(value => value.trim()).filter(Boolean) ?? [];
  if (configured.length) return configured.includes(origin);
  return url.hostname === "localhost" || url.hostname === "127.0.0.1" || allowedOriginSuffixes.some(suffix => url.hostname.endsWith(suffix));
}

function response(status: number, body: Record<string, unknown>, origin: string | null) {
  const headers: Record<string, string> = {
    "Content-Type": "application/json",
    "Cache-Control": "no-store",
    "Vary": "Origin",
  };
  if (origin && allowedOrigin(origin)) {
    headers["Access-Control-Allow-Origin"] = origin;
    headers["Access-Control-Allow-Headers"] = "content-type, apikey";
    headers["Access-Control-Allow-Methods"] = "POST, OPTIONS";
  }
  return new Response(JSON.stringify(body), { status, headers });
}

function cleanText(value: unknown, min: number, max: number): string | null {
  if (typeof value !== "string") return null;
  const text = value.trim();
  return text.length >= min && text.length <= max ? text : null;
}

function decodeImage(dataUrl: string): ValidPhoto | null {
  const match = /^data:(image\/(?:jpeg|png|webp));base64,([A-Za-z0-9+/=]+)$/.exec(dataUrl);
  if (!match) return null;
  const contentType = match[1];
  let binary: string;
  try {
    binary = atob(match[2]);
  } catch {
    return null;
  }
  if (binary.length === 0 || binary.length > maxPhotoBytes) return null;
  const bytes = new Uint8Array(binary.length);
  for (let i = 0; i < binary.length; i++) bytes[i] = binary.charCodeAt(i);
  const jpeg = contentType === "image/jpeg" && bytes[0] === 0xff && bytes[1] === 0xd8 && bytes[2] === 0xff;
  const png = contentType === "image/png" && [0x89, 0x50, 0x4e, 0x47, 0x0d, 0x0a, 0x1a, 0x0a].every((value, index) => bytes[index] === value);
  const webp = contentType === "image/webp" && String.fromCharCode(...bytes.slice(0, 4)) === "RIFF" && String.fromCharCode(...bytes.slice(8, 12)) === "WEBP";
  if (!jpeg && !png && !webp) return null;
  return { bytes, contentType, extension: contentType === "image/jpeg" ? "jpg" : contentType.slice("image/".length) };
}

async function hashIp(ip: string, pepper: string): Promise<string> {
  const digest = await crypto.subtle.digest("SHA-256", new TextEncoder().encode(`${pepper}:${ip}`));
  return Array.from(new Uint8Array(digest), byte => byte.toString(16).padStart(2, "0")).join("");
}

Deno.serve(async (req: Request) => {
  const origin = req.headers.get("origin");
  if (req.method === "OPTIONS") return allowedOrigin(origin) ? response(204, {}, origin) : response(403, { error: "Origin non autorisée." }, origin);
  if (req.method !== "POST") return response(405, { error: "Méthode non autorisée." }, origin);
  if (!allowedOrigin(origin)) return response(403, { error: "Origine non autorisée." }, origin);
  const apiKey = req.headers.get("apikey");
  if (!apiKey) return response(401, { error: "Clé API manquante." }, origin);
  const bodyLength = Number(req.headers.get("content-length") ?? 0);
  if (bodyLength > maxBodyBytes) return response(413, { error: "La demande est trop volumineuse." }, origin);

  let body: TradeInBody;
  try {
    body = await req.json() as TradeInBody;
  } catch {
    return response(400, { error: "Corps de requête invalide." }, origin);
  }
  if (new TextEncoder().encode(JSON.stringify(body)).length > maxBodyBytes) return response(413, { error: "La demande est trop volumineuse." }, origin);
  if (!body || typeof body !== "object" || !uuidPattern.test(body.submissionId ?? "")) return response(400, { error: "Identifiant de soumission invalide." }, origin);
  if (typeof body.website === "string" && body.website.trim()) return response(400, { error: "Demande rejetée." }, origin);
  const name = cleanText(body.name, 2, 160);
  const phone = cleanText(body.phone, 7, 50);
  const brand = cleanText(body.brand, 1, 80);
  const model = cleanText(body.model, 1, 120);
  const fuel = cleanText(body.fuel, 1, 40);
  const condition = cleanText(body.condition, 1, 200);
  const message = typeof body.message === "string" ? body.message.trim() : "";
  const email = typeof body.email === "string" ? body.email.trim() : "";
  if (!name || !phone || !brand || !model || !fuel || !condition || message.length > 4000 || email.length > 320 || (email && !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email))) return response(400, { error: "Vérifiez les champs de la demande." }, origin);
  if (!Number.isInteger(body.year) || body.year < 1950 || body.year > 2100 || !Number.isInteger(body.mileageKm) || body.mileageKm < 0 || body.mileageKm > 2_000_000) return response(400, { error: "Année ou kilométrage invalide." }, origin);
  if (body.consent !== true) return response(400, { error: "Le consentement est requis." }, origin);
  if (!Array.isArray(body.photos) || body.photos.length > 5 || body.photos.some(photo => typeof photo !== "string" || photo.length > 7_100_000)) return response(400, { error: "Nombre ou taille de photos invalide." }, origin);
  const photos = body.photos.map(decodeImage);
  if (photos.some(photo => photo === null)) return response(400, { error: "Format photo invalide. Utilisez JPG, PNG ou WebP jusqu’à 5 Mo par image." }, origin);
  const validPhotos = photos as ValidPhoto[];
  if (validPhotos.reduce((sum, photo) => sum + photo.bytes.length, 0) > 25 * 1024 * 1024) return response(400, { error: "La taille totale des photos dépasse 25 Mo." }, origin);

  const supabaseUrl = Deno.env.get("SUPABASE_URL");
  const serviceRoleKey = Deno.env.get("SUPABASE_SERVICE_ROLE_KEY");
  if (!supabaseUrl || !serviceRoleKey) return response(503, { error: "Service de reprise temporairement indisponible." }, origin);
  const supabase = createClient(supabaseUrl, serviceRoleKey, { auth: { persistSession: false, autoRefreshToken: false } });
  const existing = await supabase.from("leads").select("id").eq("submission_id", body.submissionId).maybeSingle();
  if (existing.error) return response(503, { error: "Service de reprise temporairement indisponible." }, origin);
  if (existing.data) return response(200, { success: true }, origin);

  const ip = req.headers.get("cf-connecting-ip") ?? req.headers.get("x-forwarded-for")?.split(",")[0]?.trim() ?? "unknown";
  const sourceIpHash = await hashIp(ip, serviceRoleKey.slice(0, 32));
  const since = new Date(Date.now() - 60 * 60 * 1000).toISOString();
  const { count, error: rateLimitError } = await supabase.from("leads").select("id", { count: "exact", head: true }).eq("source_ip_hash", sourceIpHash).gte("created_at", since);
  if (rateLimitError) return response(503, { error: "Service de reprise temporairement indisponible." }, origin);
  if ((count ?? 0) >= 5) return response(429, { error: "Limite temporaire atteinte. Réessayez plus tard ou contactez le showroom." }, origin);

  const { data: lead, error: insertError } = await supabase.from("leads").insert({
    submission_id: body.submissionId,
    type: "trade_in",
    name,
    email: email || null,
    phone,
    message,
    details: { brand, model, year: body.year, mileageKm: body.mileageKm, fuel, condition, consent: true },
    photo_paths: [],
    status: "new",
    source_ip_hash: sourceIpHash,
  }).select("id").single();
  if (insertError) {
    if (insertError.code === "23505") return response(200, { success: true }, origin);
    return response(503, { error: "La demande n’a pas pu être enregistrée." }, origin);
  }

  const uploadedPaths: string[] = [];
  for (const [index, photo] of validPhotos.entries()) {
    const path = `trade-ins/${new Date().toISOString().slice(0, 10)}/${lead.id}/${crypto.randomUUID()}-${index}.${photo.extension}`;
    const { error: uploadError } = await supabase.storage.from("trade-in-photos").upload(path, photo.bytes, {
      contentType: photo.contentType,
      cacheControl: "3600",
      upsert: false,
    });
    if (uploadError) {
      if (uploadedPaths.length) await supabase.storage.from("trade-in-photos").remove(uploadedPaths);
      await supabase.from("leads").delete().eq("id", lead.id);
      return response(503, { error: "Une photo n’a pas pu être stockée; la demande n’a pas été conservée." }, origin);
    }
    uploadedPaths.push(path);
  }
  if (uploadedPaths.length) {
    const { error: pathsError } = await supabase.from("leads").update({ photo_paths: uploadedPaths }).eq("id", lead.id);
    if (pathsError) {
      await supabase.storage.from("trade-in-photos").remove(uploadedPaths);
      await supabase.from("leads").delete().eq("id", lead.id);
      return response(503, { error: "La demande n’a pas pu être finalisée." }, origin);
    }
  }
  return response(200, { success: true }, origin);
});
