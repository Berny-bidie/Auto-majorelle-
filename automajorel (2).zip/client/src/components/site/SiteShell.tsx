import { useState, type ReactNode } from "react";
import { Link, useLocation } from "wouter";
import { Menu, Phone, X } from "lucide-react";
import { SOURCE_MEDIA } from "@shared/siteData";
import { useSiteSettings } from "@/lib/siteSettings";
import { LanguageSwitcher, useLanguage } from "@/lib/i18n";
import { WhatsAppLink } from "./Shared";
import SocialLinks, { WhatsAppMark } from "./SocialLinks";
import AssistantChatWidget from "./AssistantChatWidget";

const navItems = [["Accueil", "/"], ["Véhicules", "/vehicules"], ["Services", "/services"], ["Financement", "/financement"], ["Reprise", "/reprise"], ["Blog", "/blog"], ["À propos", "/a-propos"], ["Contact", "/contact"]] as const;

export function SiteHeader() {
  const [open, setOpen] = useState(false);
  const [location] = useLocation();
  const contact = useSiteSettings();
  return <header className="site-header">
    <div className="topline"><div className="container topline-inner"><span>Marrakech · Showroom automobile</span><div className="topline-actions"><LanguageSwitcher /><a href={`tel:${contact.phoneRaw}`}><Phone size={13} /> {contact.phone}</a></div></div></div>
    <div className="container header-main">
      <Link href="/" className="brand-lockup" onClick={() => setOpen(false)} aria-label="Auto Majorelle — Accueil"><img src={SOURCE_MEDIA.logo} alt="Majorelle Auto" width="164" height="82" /><span className="sr-only">Auto Majorelle</span></Link>
      <button className="menu-toggle" type="button" aria-label={open ? "Fermer le menu" : "Ouvrir le menu"} aria-expanded={open} onClick={() => setOpen(!open)}>{open ? <X /> : <Menu />}</button>
      <nav className={`primary-nav ${open ? "nav-open" : ""}`} aria-label="Navigation principale">{navItems.map(([label, href]) => <Link key={href} href={href} className={location === href ? "nav-link nav-active" : "nav-link"} onClick={() => setOpen(false)}>{label}</Link>)}<div className="mobile-nav-actions"><LanguageSwitcher /><WhatsAppLink message="Bonjour Auto Majorelle, je souhaite en savoir plus." className="button button-whatsapp">WhatsApp</WhatsAppLink></div></nav>
      <div className="header-actions"><WhatsAppLink message="Bonjour Auto Majorelle, je souhaite en savoir plus." className="button button-whatsapp header-whatsapp">WhatsApp</WhatsAppLink></div>
    </div>
  </header>;
}

export function SiteFooter() {
  const contact = useSiteSettings();
  return <footer className="site-footer"><div className="container footer-main">
    <div className="footer-brand"><Link href="/" aria-label="Accueil Auto Majorelle"><img src={SOURCE_MEDIA.logo} alt="Majorelle Auto" width="150" height="75" /></Link><p>Véhicules, financement et reprise à Marrakech.</p><SocialLinks /></div>
    <nav className="footer-nav" aria-label="Liens utiles">
      <div><h3>Découvrir</h3><Link href="/vehicules">Nos véhicules</Link><Link href="/services">Nos services</Link><Link href="/financement">Financement</Link><Link href="/reprise">Reprise</Link></div>
      <div><h3>Auto Majorelle</h3><Link href="/blog">Conseils & actualités</Link><Link href="/a-propos">À propos</Link><Link href="/contact">Contact</Link><Link href="/garanties">Garanties</Link></div>
    </nav>
    <div className="footer-contact"><h3>Nous trouver</h3><a href={`tel:${contact.phoneRaw}`}>{contact.phone}</a><a href={`mailto:${contact.email}`}>{contact.email}</a><p>{contact.address}</p><a className="footer-map-link" href={contact.mapsDirectionsUrl} target="_blank" rel="noreferrer">Itinéraire Google Maps ↗</a></div>
  </div><div className="container footer-bottom"><span>© {new Date().getFullYear()} Auto Majorelle · Marrakech</span><span>Informations commerciales à confirmer avec l’équipe avant votre visite.</span></div></footer>;
}

export function FloatingContact() {
  const contact = useSiteSettings();
  const { locale } = useLanguage();
  const labels = { fr: "Écrire à Auto Majorelle sur WhatsApp", en: "Message Auto Majorelle on WhatsApp", ar: "راسل Auto Majorelle عبر واتساب" };
  const messages = { fr: "Bonjour Auto Majorelle, je souhaite des informations.", en: "Hello Auto Majorelle, I would like some information.", ar: "مرحبًا Auto Majorelle، أود الحصول على معلومات." };
  return <a className="floating-whatsapp" href={`https://wa.me/${contact.whatsapp}?text=${encodeURIComponent(messages[locale])}`} target="_blank" rel="noopener noreferrer" aria-label={labels[locale]} title={labels[locale]}><WhatsAppMark /><span>WhatsApp</span></a>;
}

export function SiteShell({ children }: { children: ReactNode }) {
  return <div className="site"><SiteHeader /><main>{children}</main><SiteFooter /><FloatingContact /><AssistantChatWidget /></div>;
}
